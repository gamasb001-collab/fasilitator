// Isi URL /exec dari Deploy Web App Google Apps Script
const GAS_URL = 'https://script.google.com/macros/s/XXXX/exec';
const WA = '6285832288819'; // Arraihan Academy
